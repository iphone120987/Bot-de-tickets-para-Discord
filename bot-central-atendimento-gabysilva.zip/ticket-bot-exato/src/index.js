/*
========================================
 BOT: Central de Atendimento
 Desenvolvido por: Gaby.silva
========================================
*/
require('dotenv').config();
const {
  Client,
  GatewayIntentBits,
  Partials,
  REST,
  Routes,
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionsBitField,
  ChannelType,
} = require('discord.js');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
  partials: [Partials.Channel],
});

const config = {
  token: process.env.TOKEN,
  clientId: process.env.CLIENT_ID,
  guildId: process.env.GUILD_ID,
  categoryId: process.env.CATEGORY_ID || null,
  staffRoleId: process.env.STAFF_ROLE_ID || null,
  logChannelId: process.env.LOG_CHANNEL_ID || null,
};

const ticketOptions = {
  denuncia: {
    emoji: '⚠️',
    label: 'Denúncia',
    description: 'Para reportar algo ou alguém.',
    channelPrefix: 'denuncia',
    color: 0x2b2d31,
  },
  doacao: {
    emoji: '💰',
    label: 'Doação',
    description: 'Para contribuir com o servidor.',
    channelPrefix: 'doacao',
    color: 0x2b2d31,
  },
  suporte: {
    emoji: '🛠️',
    label: 'Suporte',
    description: 'Para dúvidas ou problemas técnicos.',
    channelPrefix: 'suporte',
    color: 0x2b2d31,
  },
  adv: {
    emoji: '🧨',
    label: 'ADV',
    description: 'Para ver sua ADV ou tentar recorrer.',
    channelPrefix: 'adv',
    color: 0x2b2d31,
  },
};

function buildPanelEmbed(guild) {
  const slots = Math.max(0, 25 - guild.channels.cache.filter(c => c.topic?.startsWith('ticket-owner:')).size);

  return new EmbedBuilder().setFooter({text:'Central de Atendimento • Criado por Gaby.silva'})
    .setColor(0x10131c)
    .setDescription(
      [
        '📩 **Sistema de Tickets — Central de Atendimento**',
        '',
        `🟢 **Tickets disponíveis:** ${slots}`,
        '✅ **Tudo certo!** Slots de tickets disponíveis normalmente.',
        '',
        'Clique no botão correspondente para abrir um ticket:',
        '',
        '⚠️ **Denúncia:** Para reportar algo ou alguém.',
        '💰 **Doação:** Para contribuir com o servidor.',
        '🛠️ **Suporte:** Para dúvidas ou problemas técnicos.',
        '🧨 **ADV:** Para ver sua ADV ou tentar recorrer.',
      ].join('\n')
    );
}

function buildPanelComponents() {
  const select = new StringSelectMenuBuilder()
    .setCustomId('ticket_select')
    .setPlaceholder('Escolha uma opção...')
    .addOptions(
      Object.entries(ticketOptions).map(([value, item]) => ({
        label: item.label,
        description: item.description,
        value,
        emoji: item.emoji,
      }))
    );

  return [new ActionRowBuilder().addComponents(select)];
}

function buildTicketButtons() {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('ticket_assumir')
        .setLabel('Assumir ticket')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('ticket_fechar')
        .setLabel('Fechar ticket')
        .setStyle(ButtonStyle.Danger)
    ),
  ];
}

async function sendLog(guild, embed) {
  if (!config.logChannelId) return;
  const channel = guild.channels.cache.get(config.logChannelId);
  if (!channel || !channel.isTextBased()) return;
  await channel.send({ embeds: [embed] }).catch(() => {});
}

async function registerCommands() {
  const commands = [
    new SlashCommandBuilder()
      .setName('painel-ticket')
      .setDescription('Envia o painel de tickets'),
  ].map(command => command.toJSON());

  const rest = new REST({ version: '10' }).setToken(config.token);
  await rest.put(Routes.applicationGuildCommands(config.clientId, config.guildId), { body: commands });
}

client.once('ready', async () => {
  console.log(`✅ Logado como ${client.user.tag}`);
  try {
    await registerCommands();
    console.log('✅ Comando /painel-ticket registrado.');
  } catch (error) {
    console.error('❌ Erro ao registrar comandos:', error);
  }
});

client.on('interactionCreate', async interaction => {
  try {
    if (interaction.isChatInputCommand()) {
      if (interaction.commandName === 'painel-ticket') {
        if (!interaction.memberPermissions.has(PermissionsBitField.Flags.Administrator)) {
          return interaction.reply({ content: 'Você precisa ser administrador para usar este comando.', ephemeral: true });
        }

        await interaction.channel.send({
          embeds: [buildPanelEmbed(interaction.guild)],
          components: buildPanelComponents(),
        });

        return interaction.reply({ content: 'Painel enviado com sucesso.', ephemeral: true });
      }
    }

    if (interaction.isStringSelectMenu() && interaction.customId === 'ticket_select') {
      const selected = interaction.values[0];
      const option = ticketOptions[selected];
      if (!option) return;

      const existing = interaction.guild.channels.cache.find(
        c => c.topic === `ticket-owner:${interaction.user.id};type:${selected}`
      );

      if (existing) {
        return interaction.reply({
          content: `Você já possui um ticket aberto aqui: ${existing}`,
          ephemeral: true,
        });
      }

      const channelName = `${option.channelPrefix}-${interaction.user.username}`
        .toLowerCase()
        .replace(/[^a-z0-9-]/g, '')
        .slice(0, 24);

      const permissionOverwrites = [
        {
          id: interaction.guild.roles.everyone.id,
          deny: [PermissionsBitField.Flags.ViewChannel],
        },
        {
          id: interaction.user.id,
          allow: [
            PermissionsBitField.Flags.ViewChannel,
            PermissionsBitField.Flags.SendMessages,
            PermissionsBitField.Flags.ReadMessageHistory,
            PermissionsBitField.Flags.AttachFiles,
            PermissionsBitField.Flags.EmbedLinks,
          ],
        },
      ];

      if (config.staffRoleId) {
        permissionOverwrites.push({
          id: config.staffRoleId,
          allow: [
            PermissionsBitField.Flags.ViewChannel,
            PermissionsBitField.Flags.SendMessages,
            PermissionsBitField.Flags.ReadMessageHistory,
            PermissionsBitField.Flags.ManageChannels,
          ],
        });
      }

      const ticketChannel = await interaction.guild.channels.create({
        name: channelName,
        type: ChannelType.GuildText,
        parent: config.categoryId || undefined,
        topic: `ticket-owner:${interaction.user.id};type:${selected}`,
        permissionOverwrites,
      });

      const openEmbed = new EmbedBuilder()
        .setColor(option.color)
        .setTitle(`${option.emoji} Ticket de ${option.label}`)
        .setDescription([
          `${interaction.user}, seu ticket foi criado com sucesso.`,
          '',
          `**Categoria:** ${option.label}`,
          `**Motivo:** ${option.description}`,
          '',
          'Explique seu caso com o máximo de detalhes possível e aguarde um membro da equipe.',
        ].join('\n'));

      await ticketChannel.send({
        content: config.staffRoleId ? `<@&${config.staffRoleId}> ${interaction.user}` : `${interaction.user}`,
        embeds: [openEmbed],
        components: buildTicketButtons(),
      });

      await sendLog(
        interaction.guild,
        new EmbedBuilder()
          .setColor(0x57f287)
          .setTitle('Ticket aberto')
          .setDescription([
            `**Usuário:** ${interaction.user.tag}`,
            `**Categoria:** ${option.label}`,
            `**Canal:** ${ticketChannel}`,
          ].join('\n'))
      );

      return interaction.reply({
        content: `Seu ticket foi criado: ${ticketChannel}`,
        ephemeral: true,
      });
    }

    if (interaction.isButton()) {
      const channel = interaction.channel;
      if (!channel || channel.type !== ChannelType.GuildText) return;

      if (interaction.customId === 'ticket_assumir') {
        await interaction.reply({
          content: `✅ ${interaction.user} assumiu este ticket.`,
        });

        await sendLog(
          interaction.guild,
          new EmbedBuilder()
            .setColor(0x5865f2)
            .setTitle('Ticket assumido')
            .setDescription([
              `**Staff:** ${interaction.user.tag}`,
              `**Canal:** ${channel}`,
            ].join('\n'))
        );
      }

      if (interaction.customId === 'ticket_fechar') {
        await interaction.reply({ content: '🔒 Fechando ticket em 5 segundos...' });

        await sendLog(
          interaction.guild,
          new EmbedBuilder()
            .setColor(0xed4245)
            .setTitle('Ticket fechado')
            .setDescription([
              `**Fechado por:** ${interaction.user.tag}`,
              `**Canal:** ${channel.name}`,
            ].join('\n'))
        );

        setTimeout(() => {
          channel.delete('Ticket fechado pelo botão').catch(() => {});
        }, 5000);
      }
    }
  } catch (error) {
    console.error('❌ Erro na interação:', error);
    if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
      await interaction.reply({ content: 'Ocorreu um erro interno no bot.', ephemeral: true }).catch(() => {});
    }
  }
});

client.login(config.token);
